from folder import battleFight

battleFight.battleFight( "Van", "Ethan",1,1,1,1,1,1)